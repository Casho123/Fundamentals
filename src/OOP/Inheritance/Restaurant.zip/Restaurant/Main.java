package OOP.Inheritance.Restaurant;

public class Main {
}
